STM32 USB CDC v1 protocol handoff, updated 2026-11-07.
Read docs/lower-controller-handoff.md first.
POSITION=0x04: absolute X/Y/yaw, int32 mm/mm/mrad.
STATUS=0x81: payload 196 bytes, frame 208 bytes.
POSE=0x82: payload 64 bytes, frame 76 bytes.
Binary mode 0 alternates both feedback types, nominal 20 Hz each.
Includes protocol documents only; no firmware, ROS bridge or motion scripts.
Reported board feedback is normal; ROS integration remains unverified.
