STM32 USB CDC v1 protocol package
Updated 2026-11-11: crane pick/place and explicit per-axis disable.
Read docs/usb-cdc-host-link.md for commands 05..0C and feedback 83/84.
Normal yaw/z, rack and gripper motion was confirmed by the user.
New coordinated actions and disable are built and simulated, awaiting hardware validation.
Pick/place coordinates are configured and enabled; safe Z=0. Download new firmware before testing.
